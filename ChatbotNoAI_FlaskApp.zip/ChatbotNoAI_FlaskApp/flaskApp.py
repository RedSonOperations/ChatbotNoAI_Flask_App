from flask import Flask, render_template, request, jsonify

application = Flask(__name__)
from main import get_response


@application.get("/")
def index_get():
    return render_template("base.html")


@application.post("/predict")
def predict():
    text = request.get_json().get("message")
    response = get_response(text)
    message = {"answer": response}
    return jsonify(message)

if __name__ == '__main__':
    application.run(host='0.0.0.0')